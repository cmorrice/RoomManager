﻿using Intel.Unite.Common.Command;
using Intel.Unite.Common.Context.Hub;
using Intel.Unite.Common.Logging;
using Intel.Unite.Common.Module.Common;
using System;
using System.Windows.Threading;
using DeviceManager.Constants;
using DeviceManager.Interfaces;
using DeviceManager.Model.EventArguments;
using DeviceManager.Sensors;
using DeviceManager.Utility;
using DeviceManager.ViewModel.Controls;
using DeviceManager.ViewModel.Factory;

namespace DeviceManager.Static
{
    public static class DeviceManagerConfig
    {
        /// <summary>
        /// Static instance of the current UI Dispatcher
        /// </summary>
        public static Dispatcher CurrentUiDispatcher { get; set; }

        /// <summary>
        /// Method instance of the HubRuntimeContext
        /// </summary>
        public static IHubModuleRuntimeContext RuntimeContext { get; set; }

        public static MarshalNativeHandleContract Contract { get; set; }
        public static DeviceManagerSensorManager PluginSensorManager { get; internal set; }
        public static IHubViewManager HubViewManager { get; set; }

        public static void SetHubViewManager(IHubViewManager hubViewManager)
        {
            HubViewManager = hubViewManager;
        }
        
        public static class Messaging
        {
            public static bool IsMessageEnumDefined(Message message)
            {
                return typeof(EventArgumentTypes).IsEnumDefined(message.DataType);
            }

            public static bool IsMessageFromClientDeviceManager(Message message)
            {
                return IsMessageFromDeviceManager(message) && message.SourceId != RuntimeContext.SessionContext.MyHubInfo.Id;
            }


            public static bool IsMessageFromHubDeviceManager(Message message)
            {
                return IsMessageFromDeviceManager(message) && message.SourceId == RuntimeContext.SessionContext.MyHubInfo.Id;
            }

            public static bool IsMessageFromDeviceManager(Message message)
            {
                return message.SourceModuleId == ModuleConstants.ModuleInfo.Id;
            }

            public static bool IsMessageForDeviceManager(Message message)
            {
                return message.TargetId == ModuleConstants.ModuleInfo.Id;
            }
        }
    }
}
