﻿using Intel.Unite.Common.Command;
using Intel.Unite.Common.Context;
using Intel.Unite.Common.Core;
using Intel.Unite.Common.Manifest;
using Intel.Unite.Common.Module.Common;
using Intel.Unite.Common.Module.Feature.Hub;
using System;
using System.Reflection;
using System.Windows.Threading;
using Intel.Unite.Common.Display;
using Intel.Unite.Common.Logging;
using DeviceManager.ClientUI;
using DeviceManager.Constants;
using DeviceManager.Utility;
using DeviceManager.Sensors;
using DeviceManager.Model.EventArguments;
using DeviceManager.Static;
using DeviceManager.UI;

namespace DeviceManager
{
    public class PluginModuleHandler : HubFeatureModuleBase
    {
        private string _html = @"<!DOCTYPE html><html><head><title>Error</title><script type='text/javascript'>window.onload=function(){alert();}</script></head><body onclick='alert()'><div>If you're reading this, something went wrong.</div></body></html>";

        public PluginModuleHandler() : base()
        {
        }

        public PluginModuleHandler(IModuleRuntimeContext runtimeContext) : base(runtimeContext)
        {
            //System.Diagnostics.Debugger.Launch();
            ConfigureModuleForClient();
        }

        private void ConfigureModuleForClient()
        {
            FeatureModuleType = FeatureModuleType.Html;
            ModuleImage = UniteImageHelper.GetUniteImageFromResource("/DeviceManager;component/Images/business-user.png", UniteImageType.Png);
            _html = ClientUiSetup.GetHtml();
        }

        public override string HtmlUrlOrContent => _html;


        public override Dispatcher CurrentUiDispatcher
        {
            get => DeviceManagerConfig.CurrentUiDispatcher;
            set
            {
                if (DeviceManagerConfig.CurrentUiDispatcher == null)
                    DeviceManagerConfig.CurrentUiDispatcher = value;
            }
        }

        public override ModuleManifest ModuleManifest => ModuleConstants.ModuleManifest;

        public override ModuleInfo ModuleInfo => ModuleConstants.ModuleInfo;

        public override void IncomingMessage(Message message)
        {
            if (!DeviceManagerConfig.Messaging.IsMessageForDeviceManager(message) &&
                !DeviceManagerConfig.Messaging.IsMessageEnumDefined(message)) return;

            RuntimeContext.LogManager.LogMessage(
                ModuleInfo.Id,
                LogLevel.Debug,
                MethodBase.GetCurrentMethod().Name,
                Enum.GetName(typeof(EventArgumentTypes), message.DataType));

            MessagingEventBroker.Process(message);
        }

        public override void Load()
        {
            DeviceManagerConfig.RuntimeContext = RuntimeContext;
            DeviceManagerConfig.HubViewManager = new HubViewManager(RuntimeContext, CurrentUiDispatcher, CreateContract);
            
            SensorConfig.Setup();
            MockSensor.Start();

            DeviceManagerConfig.HubViewManager.LoadandAllocateForAllDisplays(HubView.Type.QuickAccessIcon);
            DeviceManagerConfig.HubViewManager.LoadandAllocateForAllDisplays(HubView.Type.QuickAccessApp);
        }


        #region Methods with no funtionality but Logs Message   
        public override bool OkToSleepDisplay()
        {
            RuntimeContext.LogManager.LogMessage(
                ModuleInfo.Id,
                LogLevel.Debug,
                MethodBase.GetCurrentMethod().Name,
                "Called");
            return true;
        }

        public override void SessionKeyChanged(KeyValuePair sessionKey)
        {
            RuntimeContext.LogManager.LogMessage(
                ModuleInfo.Id,
                LogLevel.Debug,
                MethodBase.GetCurrentMethod().Name,
                "Called");
        }

        public override void Unload()
        {
            RuntimeContext.LogManager.LogMessage(
                ModuleInfo.Id,
                LogLevel.Debug,
                MethodBase.GetCurrentMethod().Name,
                "Called");
        }

        public override void UserConnected(UserInfo userInfo)
        {
            RuntimeContext.LogManager.LogMessage(
                ModuleInfo.Id,
                LogLevel.Debug,
                MethodBase.GetCurrentMethod().Name,
                "Called");
        }

        public override void UserDisconnected(UserInfo userInfo)
        {
            RuntimeContext.LogManager.LogMessage(
                ModuleInfo.Id,
                LogLevel.Debug,
                MethodBase.GetCurrentMethod().Name,
                "Called");
        }

        public override void UserInfoChanged(UserInfo userInfo)
        {
            RuntimeContext.LogManager.LogMessage(
                ModuleInfo.Id,
                LogLevel.Debug,
                MethodBase.GetCurrentMethod().Name,
                "Called");
        }

        public override void HubConnected(HubInfo hubInfo)
        {
            RuntimeContext.LogManager.LogMessage(
                ModuleInfo.Id,
                LogLevel.Debug,
                MethodBase.GetCurrentMethod().Name,
                "Called");
        }

        public override void HubDisconnected(HubInfo hubInfo)
        {
            RuntimeContext.LogManager.LogMessage(
                ModuleInfo.Id,
                LogLevel.Debug,
                MethodBase.GetCurrentMethod().Name,
                "Called");
        }

        public override void HubInfoChanged(HubInfo hubInfo)
        {
            RuntimeContext.LogManager.LogMessage(
                ModuleInfo.Id,
                LogLevel.Debug,
                MethodBase.GetCurrentMethod().Name,
                "Called");
        }
        #endregion

    }
}
