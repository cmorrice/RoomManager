﻿using System.Windows.Controls;

namespace DeviceManager.View
{
    /// <summary>
    /// Interaction logic for BackgroundView.xaml
    /// </summary>
    public partial class BackgroundView : UserControl
    {
        public BackgroundView()
        {
            InitializeComponent();
        }
    }
}
