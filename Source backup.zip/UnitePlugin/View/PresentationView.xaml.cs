﻿using System.Windows.Controls;

namespace DeviceManager.View
{
    /// <summary>
    /// Interaction logic for PresentationView.xaml
    /// </summary>
    public partial class PresentationView : UserControl
    {
        public PresentationView()
        {
            InitializeComponent();
        }
    }
}
