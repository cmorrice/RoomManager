﻿using System.Windows.Controls;

namespace DeviceManager.View
{
    /// <summary>
    /// Interaction logic for QuickAccessAppView.xaml
    /// </summary>
    public partial class QuickAccessAppView : UserControl
    {
        public QuickAccessAppView()
        {
            InitializeComponent();
        }
    }
}
