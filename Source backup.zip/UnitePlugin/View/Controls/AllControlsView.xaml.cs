﻿using System.Windows.Controls;

namespace DeviceManager.View.Controls
{
    /// <summary>
    /// Interaction logic for AllControlsView.xaml
    /// </summary>
    public partial class AllControlsView : UserControl
    {
        public AllControlsView()
        {
            InitializeComponent();
        }
    }
}
