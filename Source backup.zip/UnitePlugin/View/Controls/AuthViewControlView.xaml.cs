﻿using System.Windows.Controls;
using DeviceManager.ViewModel.Controls;
using DeviceManager.ViewModel.Factory;

namespace DeviceManager.View.Controls
{
    /// <summary>
    /// Interaction logic for AuthViewControlView.xaml
    /// </summary>
    public partial class AuthViewControlView : UserControl
    {
        public AuthViewControlView()
        {
            InitializeComponent();
            DataContext = SingletonViewModelFactory<AuthViewControlViewModel>.GetInstance;
        }
    }
}
