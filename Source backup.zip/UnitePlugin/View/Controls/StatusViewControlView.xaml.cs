﻿using System.Windows.Controls;
using DeviceManager.ViewModel.Controls;
using DeviceManager.ViewModel.Factory;

namespace DeviceManager.View.Controls
{
    /// <summary>
    /// Interaction logic for StatusViewView.xaml
    /// </summary>
    public partial class StatusViewControlView : UserControl
    {
        public StatusViewControlView()
        {
            InitializeComponent();
            DataContext = SingletonViewModelFactory<StatusViewControlViewModel>.GetInstance;
        }
    }
}
