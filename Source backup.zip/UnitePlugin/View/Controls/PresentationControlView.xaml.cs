﻿using System.Windows.Controls;
using DeviceManager.ViewModel.Controls;
using DeviceManager.ViewModel.Factory;

namespace DeviceManager.View.Controls
{
    /// <summary>
    /// Interaction logic for PresentationControlView.xaml
    /// </summary>
    public partial class PresentationControlView : UserControl
    {
        public PresentationControlView()
        {
            InitializeComponent();
            DataContext = SingletonViewModelFactory<PresentationControlViewModel>.GetInstance;
        }
    }
}
