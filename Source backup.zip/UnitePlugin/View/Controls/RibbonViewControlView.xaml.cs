﻿using System.Windows.Controls;
using DeviceManager.ViewModel.Controls;
using DeviceManager.ViewModel.Factory;

namespace DeviceManager.View.Controls
{
    /// <summary>
    /// Interaction logic for RibbonViewControlView.xaml
    /// </summary>
    public partial class RibbonViewControlView : UserControl
    {
        public RibbonViewControlView()
        {
            InitializeComponent();
            DataContext = SingletonViewModelFactory<RibbonViewControlViewModel>.GetInstance;
        }
    }
}
