﻿using System.Windows.Controls;

namespace DeviceManager.View
{
    /// <summary>
    /// Interaction logic for PartialBackgroundView.xaml
    /// </summary>
    public partial class PartialBackgroundView : UserControl
    {
        public PartialBackgroundView()
        {
            InitializeComponent();
        }
    }
}
