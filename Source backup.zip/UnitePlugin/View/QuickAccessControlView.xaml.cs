﻿using System.Windows;
using System.Windows.Controls;

namespace UnitePlugin.View
{
    /// <summary>
    /// Interaction logic for QuickAccessControlView.xaml
    /// </summary>
    public partial class QuickAccessControlView : UserControl
    {
        public QuickAccessControlView()
        {
            InitializeComponent();
        }
    }
}
