﻿using System.Windows.Controls;

namespace DeviceManager.View
{
    /// <summary>
    /// Interaction logic for QuickAccessIconView.xaml
    /// </summary>
    public partial class QuickAccessIconView : UserControl
    {
        public QuickAccessIconView()
        {
            InitializeComponent();
        }
    }
}
