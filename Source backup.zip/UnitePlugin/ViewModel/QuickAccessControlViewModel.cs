﻿using System;
using System.Windows;
using System.Windows.Input;
using UnitePlugin.Utility;

namespace UnitePlugin.ViewModel
{
    [Serializable]
    public class QuickAccessControlViewModel : HubViewModel
    {
        public QuickAccessControlViewModel() : base()
        {
        }
    }
}
