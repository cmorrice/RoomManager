﻿using System;

namespace DeviceManager.Model.EventArguments
{
    public class ToggleAuthViewEventArgs : EventArgs
    {
        public Guid SourceGuid;
    }
}