﻿using System;
using DeviceManager.ViewModel.Controls;

namespace DeviceManager.Model.EventArguments
{
    ///Create in DeviceManager.Model.EventArguments
    ///and add to enum EventArgumentTypes
    [Serializable]
    public class ShowPartialBackgroundViewEventArgs : HubViewEventArgs
    {
        public PartialBackgroundControlViewModel ViewModel { get; set; }
    }
}
