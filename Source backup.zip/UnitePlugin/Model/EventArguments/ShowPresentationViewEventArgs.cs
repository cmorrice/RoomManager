﻿using System;
using DeviceManager.ViewModel.Controls;

namespace DeviceManager.Model.EventArguments
{
    ///Create in DeviceManager.Model.EventArguments
    ///and add to enum EventArgumentTypes
    [Serializable]
    public class ShowPresentationViewEventArgs : HubViewEventArgs
    {
        public PresentationControlViewModel ViewModel { get; set; }
    }
}