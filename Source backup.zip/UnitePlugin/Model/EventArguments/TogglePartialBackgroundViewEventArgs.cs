﻿using System;

namespace DeviceManager.Model.EventArguments
{
    public class TogglePartialBackgroundViewEventArgs : EventArgs
    {
        public Guid SourceGuid;
    }
}