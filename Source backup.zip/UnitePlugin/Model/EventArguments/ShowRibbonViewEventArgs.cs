﻿using System;
using DeviceManager.ViewModel.Controls;

namespace DeviceManager.Model.EventArguments
{
    ///Create in DeviceManager.Model.EventArguments
    ///and add to enum EventArgumentTypes
    [Serializable]
    public class ShowRibbonViewEventArgs : HubViewEventArgs
    {
        public RibbonViewControlViewModel ViewModel { get; set; }
    }
}
