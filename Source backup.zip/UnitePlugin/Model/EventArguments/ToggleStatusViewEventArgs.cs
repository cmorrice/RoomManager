﻿using System;

namespace DeviceManager.Model.EventArguments
{
    public class ToggleStatusViewEventArgs : EventArgs
    {
        public Guid SourceGuid;
    }
}