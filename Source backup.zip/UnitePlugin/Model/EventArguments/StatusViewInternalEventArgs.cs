﻿using System;

namespace DeviceManager.Model.EventArguments
{
    public class StatusViewInternalEventArgs : EventArgs
    {
    }
}