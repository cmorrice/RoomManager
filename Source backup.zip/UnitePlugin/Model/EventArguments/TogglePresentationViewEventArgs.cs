﻿using System;

namespace DeviceManager.Model.EventArguments
{
    public class TogglePresentationViewEventArgs : EventArgs
    {
        public Guid SourceGuid;
    }
}